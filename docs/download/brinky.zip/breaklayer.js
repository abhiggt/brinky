(()=>{if(globalThis.BrinkyBreak)return;const xt=`
.bl{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;gap:32px;padding:24px;
font-family:ui-rounded,ui-sans-serif,-apple-system,BlinkMacSystemFont,"SF Pro Rounded","Segoe UI",Inter,sans-serif;
--fg:#fff;--mut:rgba(255,255,255,.8);--line:rgba(255,255,255,.34);--hover:rgba(255,255,255,.14);--track:rgba(255,255,255,.2);--card:rgba(17,22,32,.78);
background:rgba(8,11,18,.68);backdrop-filter:blur(10px) saturate(105%);-webkit-backdrop-filter:blur(10px) saturate(105%);
color:var(--fg);opacity:1;animation:bl-in .2s ease-out;transition:opacity .3s ease,background 1.4s ease;pointer-events:auto;cursor:default;user-select:none;outline:none}
/* modest machines: a solid scrim instead of a live blur, so the first frame is never slow */
.bl.lite{backdrop-filter:none;-webkit-backdrop-filter:none;background:rgba(8,11,18,.88)}
.bl.lite[data-look="light"]{background:rgba(248,249,251,.96)}
.bl.lite.away{background:rgba(4,6,10,.96)}
.sipline{display:flex;align-items:center;gap:6px;justify-content:center;font-size:13px;font-weight:650;color:var(--mut);margin:-8px 0 16px}
.sipline[hidden]{display:none}
.sipline svg{width:14px;height:14px}
.bl[data-look="light"]{--fg:#0f172a;--mut:rgba(15,23,42,.74);--line:rgba(15,23,42,.24);--hover:rgba(15,23,42,.07);--track:rgba(15,23,42,.13);--card:rgba(255,255,255,.88);
background:rgba(248,249,251,.82)}
.bl.away,.bl[data-look="light"].away{--fg:rgba(255,255,255,.9);--mut:rgba(255,255,255,.72);--line:rgba(255,255,255,.26);--hover:rgba(255,255,255,.12);--track:rgba(255,255,255,.14);--card:rgba(20,24,32,.7);background:rgba(4,6,10,.94)}
.bl.gone{opacity:0}
@keyframes bl-in{from{opacity:.45}} /* visible on its very first frame */
.bl *{box-sizing:border-box;margin:0}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
.col{display:flex;flex-direction:column;align-items:center;text-align:center;max-width:460px}
.kind{font-size:12px;letter-spacing:.16em;text-transform:uppercase;color:var(--mut);font-weight:650;margin-bottom:14px}
.ring{position:relative;width:204px;height:204px;transition:opacity 1.2s}
.ring svg{position:absolute;inset:0;transform:rotate(-90deg)}
.ring circle{fill:none;stroke-width:3}
.ring .tr{stroke:var(--track)}
.ring .br{stroke:var(--fg);stroke-linecap:round;transition:stroke-dashoffset .3s linear}
.ring .me{position:absolute;inset:0;display:grid;place-items:center}
.ring .me img{width:116px;height:auto;transform-origin:50% 85%;transition:transform 4s ease-in-out;filter:drop-shadow(0 10px 18px rgba(0,0,0,.2))}
.time{font-size:52px;font-weight:300;letter-spacing:-1px;font-variant-numeric:tabular-nums;margin-top:10px;line-height:1.1;transition:opacity 1.2s}
.hint{font-size:12px;letter-spacing:.1em;text-transform:uppercase;color:var(--mut);height:18px;font-weight:600}
.msg{font-size:18px;line-height:1.45;margin:18px 0 22px;min-height:52px;transition:opacity .4s,font-size 1s;font-weight:500}
.away .ring,.away .time{opacity:.22}
.away .msg{font-size:21px}
.away .btns{opacity:.4;transition:opacity .4s}
.away .btns:hover,.away .btns:focus-within{opacity:1}
.btns{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;transition:opacity 1s}
.btns button{all:unset;position:relative;overflow:hidden;cursor:pointer;padding:10px 16px;border-radius:999px;border:1px solid var(--line);font-size:13.5px;font-weight:650;color:var(--fg);transition:background .15s}
.btns button:hover{background:var(--hover)}
.btns button:focus-visible{outline:2px solid var(--fg);outline-offset:2px}
.btns button.pri{background:var(--fg);color:#0b1220;border-color:transparent}
.bl[data-look="light"]:not(.away) .btns button.pri{color:#fff}
.btns button.ok{border-color:transparent;background:var(--hover);cursor:default;color:var(--fg)}
.btns button i{position:absolute;inset:0;background:var(--hover);transform:scaleX(var(--p,0));transform-origin:left;pointer-events:none}
.btns button span{position:relative}
.btns.gone{visibility:hidden}
/* movement breaks: Brinky in the ring shows each exercise, with big type underneath */
.exinfo{display:flex;flex-direction:column;align-items:center;gap:10px;margin-top:16px;width:min(560px,100%)}
.exinfo[hidden]{display:none}
.segs{display:flex;gap:6px;margin-bottom:8px}
.segs i{width:26px;height:4px;border-radius:9px;background:var(--track);overflow:hidden}
.segs b{display:block;height:100%;width:0;background:var(--fg);border-radius:inherit}
.extitle{font-size:clamp(26px,3.6vw,36px);font-weight:700;letter-spacing:-.5px;line-height:1.15;transition:opacity .35s}
.exhow{font-size:clamp(15.5px,1.9vw,18.5px);color:var(--mut);line-height:1.5;max-width:44ch;min-height:3em;transition:opacity .35s}
.exnext{font-size:12.5px;color:var(--mut);font-weight:600;letter-spacing:.02em;transition:opacity .35s}
.swap .extitle,.swap .exhow,.swap .exnext{opacity:0}
.bl.move{overflow:auto;align-items:safe center}
.move .col{max-width:none;width:min(640px,100%);margin:auto 0}
.move .ring{width:248px;height:248px}
.move .ring .me img{width:146px}
.move .time{font-size:22px;font-weight:500;margin-top:14px;color:var(--mut);letter-spacing:0}
.move .hint{height:16px}
.move .msg{font-size:14.5px;color:var(--mut);margin:20px 0 22px;min-height:0}
.move.over .msg{font-size:19px;color:var(--fg)}
/* Brinky acts out each exercise */
.me{transform-origin:50% 72%}
.move .me.a-far{animation:bk-drift 6s ease-in-out infinite}
.move .me.a-nearfar{animation:bk-focus 4s ease-in-out infinite}
.move .me.a-neck{animation:bk-tilt 5s ease-in-out infinite}
.move .me.a-shoulders{animation:bk-shrug 3s ease-in-out infinite}
.move .me.a-wrist{animation:bk-sway 3.5s ease-in-out infinite}
.move .me.a-reach{animation:bk-reach 4s ease-in-out infinite}
.move .me.a-walk{animation:bk-walk 1s ease-in-out infinite}
@keyframes bk-drift{0%,100%{transform:translateX(-12px)}50%{transform:translateX(12px)}}
@keyframes bk-focus{0%,40%,100%{transform:scale(1)}50%,90%{transform:scale(.82)}}
@keyframes bk-tilt{0%,100%{transform:rotate(-13deg)}50%{transform:rotate(13deg)}}
@keyframes bk-shrug{0%,100%{transform:translateY(0)}35%{transform:translateY(-12px)}65%{transform:translateY(4px)}}
@keyframes bk-sway{0%,100%{transform:rotate(-5deg)}50%{transform:rotate(5deg)}}
@keyframes bk-reach{0%,100%{transform:scale(1,1)}50%{transform:scale(.94,1.14)}}
@keyframes bk-walk{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
@media (max-width:760px){.bl{flex-direction:column;overflow:auto;justify-content:flex-start;padding-top:32px}}
@media (max-height:740px){.move .ring{width:178px;height:178px}.move .ring .me img{width:104px}.move .time{margin-top:10px;font-size:20px}
.exinfo{gap:6px;margin-top:6px}.exhow{min-height:0}.move .msg{margin:12px 0 14px}}
@media (prefers-reduced-motion: reduce){.ring .me img{transition:none}.move .me{animation:none!important}.bl{transition:opacity .2s}}
`,$=[{t:"Look far away",h:"Find the farthest thing you can see, out of a window if you can, and let your eyes rest on it.",a:"far",m:"happy"},{t:"Near, then far",h:"Hold up your thumb about 25 cm away. Focus on it, then on something across the room. Swap every few seconds.",a:"nearfar",m:"surprised"},{t:"Neck tilt",h:"Ear toward shoulder for a slow breath, then the other side. I'll chime at halfway.",a:"neck",m:"calm",sides:!0},{t:"Slow blinks",h:"Close your eyes gently for two seconds, then blink slowly ten times.",a:"blink",m:"calm"},{t:"Shoulder rolls",h:"Lift your shoulders to your ears, roll them back and let them drop. Slow and big.",a:"shoulders",m:"proud"},{t:"Palming",h:"Rub your palms warm, cup them over closed eyes and breathe. I'll tick when it's time to open them.",a:"palming",m:"calm"},{t:"Wrist stretch",h:"Arm out, palm up, gently pull your fingers back. Switch hands at the chime.",a:"wrist",m:"wink",sides:!0},{t:"Stand and reach",h:"Stand up, reach both arms overhead and lengthen your spine.",a:"reach",m:"excited"},{t:"Walk and sip",h:"Walk to refill your glass and take a few sips on the way back.",a:"walk",m:"happy"}],Q={calm:[["breathe in",4,1],["breathe out",4,0]],box:[["breathe in",4,1],["hold",4,1],["breathe out",4,0],["hold",4,0]],478:[["breathe in",4,1],["hold",7,1],["breathe out",8,0]]};let E;const Z=()=>{try{return E||=new AudioContext,E.state==="suspended"&&E.resume(),E}catch{return null}};function q(a,e,n,s,l="sine"){const o=Z();if(!o)return;const f=o.createOscillator(),u=o.createGain();f.type=l,f.frequency.value=a,u.gain.setValueAtTime(0,o.currentTime+e),u.gain.linearRampToValueAtTime(s,o.currentTime+e+.02),u.gain.exponentialRampToValueAtTime(1e-4,o.currentTime+e+n),f.connect(u).connect(o.destination),f.start(o.currentTime+e),f.stop(o.currentTime+e+n+.05)}function F(a,e,n){const s=e*.2;a==="chime"&&(n?[784,1046.5]:[523.25,659.25,784]).forEach((l,o)=>q(l,o*.14,1.4,s)),a==="bowl"&&[220,440.6,661.8,883.2].forEach((l,o)=>q(l,0,4-o*.6,s/(o+1))),a==="bell"&&[880,1760,2637].forEach((l,o)=>q(l,n?.2:0,2.2-o*.5,s/(o+1.5),"triangle"))}const _=a=>q(1320,0,.18,a*.08,"triangle");function yt(a,e){const n=a&&a!=="none"&&Z();if(!n)return()=>{};const s=n.sampleRate*4,l=n.createBuffer(1,s,n.sampleRate),o=l.getChannelData(0);let f=0;for(let d=0;d<s;d++){const g=Math.random()*2-1;a==="brown"?(f=(f+.02*g)/1.02,o[d]=f*3.5):o[d]=g}const u=n.createBufferSource();u.buffer=l,u.loop=!0;const m=n.createBiquadFilter(),r=n.createGain();if(m.type=a==="rain"?"highpass":"lowpass",m.frequency.value=a==="rain"?1200:a==="ocean"?500:900,r.gain.value=0,r.gain.linearRampToValueAtTime(e*(a==="rain"?.1:.25),n.currentTime+2),u.connect(m).connect(r).connect(n.destination),a==="ocean"){const d=n.createOscillator(),g=n.createGain();d.frequency.value=.09,g.gain.value=e*.15,d.connect(g).connect(r.gain),d.start()}return u.start(),()=>{r.gain.linearRampToValueAtTime(0,n.currentTime+.8),setTimeout(()=>u.stop(),900)}}const R=a=>{const e=Math.max(0,Math.ceil(a/1e3)),n=Math.floor(e/60);return n>=60?`${Math.floor(n/60)}:${String(n%60).padStart(2,"0")}:${String(e%60).padStart(2,"0")}`:`${n}:${String(e%60).padStart(2,"0")}`},tt=a=>({short:"Look away",long:"Movement break",planned:a.label||"Break"})[a.kind]||"Break";function et(a){const e=globalThis.BrinkyMascot,n=tt(a),s=a.holdToSkip!==!1,l=document.createElement("template");l.innerHTML=`<div class="bl" data-look="${a.look==="light"?"light":"dark"}" role="dialog" aria-modal="true" aria-label="${n}" tabindex="-1">
<div class="sr" aria-live="polite"></div>
<div class="col">
<div class="kind">${n}</div>
<div class="ring"><svg viewBox="0 0 204 204"><circle class="tr" cx="102" cy="102" r="98"/><circle class="br" cx="102" cy="102" r="98"/></svg>
<div class="me">${e?e.html({mood:"calm",size:116}):""}</div></div>
<div class="time">${R(a.endsAt-Date.now())}</div>
<div class="hint"></div>
<div class="exinfo" hidden><div class="segs" aria-hidden="true"></div><div class="extitle"></div><div class="exhow"></div><div class="exnext"></div></div>
<p class="msg"></p>
<div class="sipline" hidden><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5c2.6 3.7 6.5 7.9 6.5 12A6.5 6.5 0 0 1 5.5 14.5c0-4.1 3.9-8.3 6.5-12z"/></svg><span></span></div>
<div class="btns">
<button data-a="water" class="${a.sip?"pri":""}"><span>${a.sip?"I had a glass":"I had some water"}</span></button>
${a.noSnooze?"":'<button data-a="postpone"><span>5 more minutes</span></button>'}
<button data-a="skip" title="${s?"Hold to skip":"Skip"}"><i></i><span>Skip</span></button>
</div>
</div>
</div>`;const o=l.content.firstElementChild;return((navigator.hardwareConcurrency||8)<=4||(navigator.deviceMemory||8)<=4)&&o.classList.add("lite"),o}function vt(a,e,n=()=>{}){const s=globalThis.BrinkyMascot;nt(a);const l=Math.max(1e3,e.endsAt-e.startedAt),o=e.kind==="short",f=tt(e),u=e.holdToSkip!==!1,m=et(e);a.appendChild(m);const r=t=>m.querySelector(t),d=r(".me img"),g=r(".br"),at=2*Math.PI*98,P=r(".sr");g.style.strokeDasharray=at;const N=[],B=(t,i)=>{const c=setInterval(t,i);return N.push(c),c},h=(t,i)=>{const c=setTimeout(t,i);return N.push(c),c},C=!!(e.primary&&e.volume&&e.sound!=="none"),H=document.activeElement&&document.activeElement!==document.body?document.activeElement:null;try{H?.blur?.(),m.focus({preventScroll:!0})}catch{}const wt=a.host||m,z=(e.messages||[]).filter(Boolean);let kt=Math.floor(Math.random()*Math.max(1,z.length)),it=0;const rt=()=>z[kt++%z.length]||"Rest your eyes.",ot=String(e.name||"").trim(),w=ot?`, ${ot}`:"",Ct=e.postCall?`That was a ${e.postCall}-minute call${w}. Look out of a window for a moment.`:e.sip?o?`Look away${w}, and take a sip of water.`:`Stand up and stretch${w}. Refill your water too.`:o?rt():`Stand up and stretch${w}. Refill your water too.`;r(".msg").textContent=Ct,P.textContent=`${f}. ${R(l)}.`,z.length>1&&!e.sip&&!e.postCall&&(it=B(()=>{if(p||Y)return;const t=r(".msg");t.style.opacity=0,h(()=>{p||(t.textContent=rt(),t.style.opacity=1)},400)},9e3));let Y=!1,j=!1,V=!1,S="calm";o&&e.lookAway!==!1&&h(()=>{p||(Y=!0,m.classList.add("away"),!e.sip&&!e.postCall&&(r(".msg").textContent=`Look out of a window${w}. I'll chime when it's time.`),s?.set(d,"sleepy"))},2500);const st=Q[e.breath]||Q.calm;let St=0,p=!1;if((function t(){if(p)return;const[i,c,b]=st[St++%st.length];!j&&!V&&(r(".hint").textContent=i),d.style.transitionDuration=`${c}s`,d.style.transform=b?"scale(1.1, 1.08)":"scale(.94, .95)",h(t,c*1e3)})(),e.exercises&&!o&&l>=2e4){const t=e.stepMs||3e4,i=Math.min(8,Math.max(1,Math.round(l/t))),c=i===8&&l>8*t?t:l/i,b=l-i*c>2e4,L=r(".exinfo"),I=r(".segs"),ut=r(".me");V=!0,L.hidden=!1,m.classList.add("move"),r(".hint").textContent="",I.innerHTML=Array.from({length:i},()=>"<i><b></b></i>").join("");let M=0,K=0;const ft=()=>{if(p)return;if(M>=i){if(!b||M>i)return;M++,L.classList.add("swap"),h(()=>{p||(r(".extitle").textContent="Free time",r(".exhow").textContent="Walk around, refill your water, look out of a window. I'll chime when it's time.",r(".exnext").textContent="That's all the moves",L.classList.remove("swap"))},350),ut.className="me",clearInterval(K),S="happy",s?.set(d,S),[...I.children].forEach(k=>{const D=k.firstChild;D.style.transition="none",D.style.width="100%"}),C&&_(e.volume);return}const x=M,y=$[((e.exStart||0)+x)%$.length],Mt=$[((e.exStart||0)+x+1)%$.length],ht=()=>{p||(r(".extitle").textContent=y.t,r(".exhow").textContent=y.h,r(".exnext").textContent=`Exercise ${x+1} of ${i} \xB7 ${x+1<i?`Up next: ${Mt.t}`:"Last one"}`,L.classList.remove("swap"))};if(x>0?(L.classList.add("swap"),h(ht,350)):ht(),P.textContent=`${y.t}. ${y.h}`,ut.className=`me a-${y.a}`,S=y.m,s?.set(d,S),clearInterval(K),y.a==="blink"){let k=!0;K=B(()=>{p||s?.set(d,(k=!k)?"calm":"happy")},1600)}[...I.children].forEach((k,D)=>{const bt=k.firstChild;bt.style.transition="none",bt.style.width=D<x?"100%":"0"});const gt=I.children[x].firstChild;requestAnimationFrame(()=>requestAnimationFrame(()=>{gt.style.transition=`width ${Math.max(0,c-300)}ms linear`,gt.style.width="100%"})),C&&x>0&&_(e.volume),y.sides&&C&&h(()=>!p&&F("chime",e.volume*.5,!0),c/2),M++};ft(),B(ft,c)}let G=0,v=0,W=0;const T=r('button[data-a="skip"]'),Tt=t=>{j=!0,r(".hint").textContent=t,h(()=>{j=!1},1600)},X=()=>{if(p)return;if(!u)return n("skip");v=performance.now();const t=()=>{const i=Math.min(1,(performance.now()-v)/600);T.style.setProperty("--p",i),i<1&&v&&(W=requestAnimationFrame(t))};t(),G=setTimeout(()=>{v=0,n("skip")},600)},O=(t=!0)=>{if(!v)return;const i=performance.now()-v<600;clearTimeout(G),cancelAnimationFrame(W),v=0,T.style.setProperty("--p",0),i&&t&&Tt("hold to skip")};T.addEventListener("pointerdown",t=>{t.preventDefault(),X()}),T.addEventListener("pointerup",()=>O()),T.addEventListener("pointerleave",()=>O(!1)),m.addEventListener("click",t=>{const i=t.target.closest("button[data-a]");if(!i||p)return;const c=i.dataset.a;if(c==="skip"){t.detail===0&&X();return}if(c==="water"){if(i.classList.contains("ok"))return;i.classList.remove("pri"),i.classList.add("ok"),i.querySelector("span").textContent="Logged, thank you",s?.set(d,"proud"),h(()=>!p&&s?.set(d,Y?"sleepy":S),2500),n("water")}else n(c)}),m.addEventListener("wheel",t=>t.preventDefault(),{passive:!1});const lt=t=>{if(A)return;const i=t.composedPath?t.composedPath():[],c=i.includes(m)||i.includes(wt);if(t.key==="Escape"){if(t.preventDefault(),t.stopImmediatePropagation(),p)return;t.type==="keydown"&&!t.repeat&&X(),t.type==="keyup"&&O();return}if(!(c&&(t.key==="Tab"||t.key==="Enter"||t.key===" "))){if(t.key==="Tab"&&t.type==="keydown")try{m.querySelector("button")?.focus()}catch{}t.preventDefault(),t.stopImmediatePropagation()}};for(const t of["keydown","keyup","keypress"])addEventListener(t,lt,!0);const ct=t=>{A||(t.preventDefault(),t.stopImmediatePropagation())};addEventListener("beforeinput",ct,!0);let U=()=>{};C&&requestAnimationFrame(()=>h(()=>{if(!p)try{F(e.sound,e.volume),U=yt(e.ambient,e.volume)}catch{}},0));let J=0,dt=Date.now();const mt=()=>{const t=Date.now(),i=e.endsAt-t;if(document.visibilityState==="visible"&&(J+=Math.min(1e3,t-dt)),dt=t,r(".time").textContent=i>0?R(i):"0:00",g.style.strokeDashoffset=at*(1-Math.max(0,i)/l),i<=0&&!p){if(p=!0,clearInterval(it),m.classList.remove("away"),r(".msg").textContent=`Nice${w}. Your eyes thank you.`,V&&(r(".me").className="me",r(".exinfo").hidden=!0,m.classList.add("over")),r(".hint").textContent="back to it",r(".btns").classList.add("gone"),P.textContent="Break over.",s?.set(d,"proud"),d.style.transform="scale(1)",U(),C)try{F(e.sound,e.volume,!0)}catch{}h(()=>n("done",{seenMs:Math.min(J,l)}),1400)}};mt(),B(mt,250);let A=!1;function Lt(){if(!A){A=!0,p=!0,N.forEach(t=>{clearInterval(t),clearTimeout(t)}),clearTimeout(G),cancelAnimationFrame(W);for(const t of["keydown","keyup","keypress"])removeEventListener(t,lt,!0);removeEventListener("beforeinput",ct,!0),U(),m.classList.add("gone"),setTimeout(()=>m.remove(),600);try{H?.isConnected&&H.focus({preventScroll:!0})}catch{}}}function pt({glass:t,goal:i}={}){if(p)return;const c=r(".sipline"),b=r('button[data-a="water"]');t&&i&&(c.querySelector("span").textContent=`Glass ${t} of ${i} today`,c.hidden=!1),b&&!b.classList.contains("ok")&&(b.classList.add("pri"),b.querySelector("span").textContent="I had a glass")}return e.sip&&pt(e),{end:Lt,sip:pt,get seenMs(){return J}}}function nt(a,e){if(!a.querySelector?.("style[data-bl]")){const s=document.createElement("style");s.dataset.bl="1",s.textContent=xt,a.appendChild(s)}if(!e)return;const n=et({...e,startedAt:Date.now(),endsAt:Date.now()+(e.dur||2e4)});n.style.cssText="visibility:hidden;animation:none;transition:none",e.kind!=="short"&&(n.classList.add("move"),n.querySelector(".exinfo").hidden=!1,n.querySelector(".extitle").textContent="Neck tilt",n.querySelector(".exhow").textContent="Ear toward shoulder for a slow breath."),n.querySelector(".time").textContent="0:20",n.querySelector(".msg").textContent="Look away.",a.appendChild(n),n.getBoundingClientRect(),n.remove()}globalThis.BrinkyBreak={start:vt,prepare:nt}})();
